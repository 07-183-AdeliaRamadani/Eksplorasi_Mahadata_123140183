# Replikasi Parsial DMRDF dengan Data Ritel Daring

Nama: Adelia Ramadani  
NIM: 123140183

Proyek ini mereplikasi secara parsial alur artikel Narayanan, Samuel, dan Chacko (2020): pembersihan data redundan, pembentukan fitur, dan klasifikasi Logistic Regression. Data yang digunakan adalah **Online Retail** dari UCI Machine Learning Repository, sehingga tidak memakai data Low Carbon London.

## Isi berkas

- `src/experiment.py` - skrip eksperimen yang dapat menggunakan PySpark bila tersedia; bila tidak, ia menjalankan padanan lokal berbasis pandas agar hasil tetap dapat direproduksi pada komputer tanpa Java/Spark.
- `data/Online Retail.xlsx` - data sumber UCI (diunduh otomatis bila belum ada).
- `results/metrics.json` dan `results/product_features.csv` - hasil yang dihasilkan ulang oleh skrip.

## Cara menjalankan

1. Instal Python 3.10+ dan Java 17 (Java diperlukan hanya untuk mode Spark).
2. Buat lingkungan virtual lalu jalankan `pip install -r requirements.txt`.
3. Jalankan `python src/experiment.py`.
4. Baca `results/metrics.json` untuk metrik dan `results/product_features.csv` untuk data fitur per produk.

Untuk memaksa mode Spark, instal PySpark dan jalankan dengan `--engine spark`. Untuk menjalankan padanan lokal yang digunakan dalam laporan, jalankan `python src/experiment.py --engine pandas`.

## Catatan metodologis

Label `sukses` didefinisikan sebagai produk dengan pendapatan bersih pada kuartil atas dalam subset yang dianalisis. Ini adalah keputusan eksperimen untuk menggantikan label keberhasilan produk pra-peluncuran yang tidak tersedia pada data UCI; karena itu eksperimen ini adalah simulasi/replikasi parsial, bukan klaim mereplikasi angka artikel secara penuh.

## Sumber

- Narayanan, S., Samuel, P., & Chacko, M. (2020). Improving prediction with enhanced Distributed Memory-based Resilient Dataset Filter. *Journal of Big Data, 7*, 13. https://doi.org/10.1186/s40537-020-00292-y
- Chen, D. (2015). Online Retail [Data set]. UCI Machine Learning Repository. https://archive.ics.uci.edu/dataset/352/online-retail
