"""Replikasi parsial DMRDF Narayanan et al. (2020) pada UCI Online Retail.

Mode Spark melakukan pembacaan CSV dan transformasi RDD sederhana bila PySpark/Java
tersedia. Mode pandas adalah padanan lokal deterministik untuk verifikasi cepat.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import urllib.request
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "Online Retail.xlsx"
RESULTS = ROOT / "results"
URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/00352/Online%20Retail.xlsx"


def download_if_needed() -> None:
    DATA.parent.mkdir(parents=True, exist_ok=True)
    if not DATA.exists():
        print("Mengunduh data UCI Online Retail...")
        urllib.request.urlretrieve(URL, DATA)


def sigmoid(x: float) -> float:
    x = max(min(x, 35), -35)
    return 1.0 / (1.0 + math.exp(-x))


def fit_logistic(X, y, lr=0.08, epochs=800):
    """Logistic regression kecil tanpa scikit-learn agar dependensi tetap ringan."""
    n, p = len(X), len(X[0])
    w = [0.0] * (p + 1)
    for _ in range(epochs):
        grad = [0.0] * (p + 1)
        for row, target in zip(X, y):
            prob = sigmoid(w[0] + sum(a * b for a, b in zip(w[1:], row)))
            error = prob - target
            grad[0] += error
            for j, value in enumerate(row):
                grad[j + 1] += error * value
        for j in range(p + 1):
            w[j] -= lr * grad[j] / n
    return w


def predict(w, X):
    return [int(sigmoid(w[0] + sum(a * b for a, b in zip(w[1:], row))) >= 0.5) for row in X]


def score(y, pred):
    tp = sum(a == 1 and b == 1 for a, b in zip(y, pred))
    tn = sum(a == 0 and b == 0 for a, b in zip(y, pred))
    fp = sum(a == 0 and b == 1 for a, b in zip(y, pred))
    fn = sum(a == 1 and b == 0 for a, b in zip(y, pred))
    precision = tp / (tp + fp) if tp + fp else 0
    recall = tp / (tp + fn) if tp + fn else 0
    return {"accuracy": round((tp + tn) / len(y), 4), "precision": round(precision, 4),
            "recall": round(recall, 4), "f1": round(2 * precision * recall / (precision + recall), 4) if precision + recall else 0,
            "confusion_matrix": {"tp": tp, "tn": tn, "fp": fp, "fn": fn}}


def prepare_features():
    """DMRDF sederhana: hapus duplikat transaksi lalu agregasi fitur per produk."""
    raw = pd.read_excel(DATA)
    raw.columns = [c.strip() for c in raw.columns]
    initial_rows = len(raw)
    df = raw.dropna(subset=["StockCode", "Description", "Quantity", "UnitPrice"])
    df = df[(df["Quantity"] > 0) & (df["UnitPrice"] > 0)]
    # Menghapus baris transaksi identik: padanan sederhana tahap eliminasi redundansi DMRDF.
    df = df.drop_duplicates(subset=["InvoiceNo", "StockCode", "Quantity", "UnitPrice", "CustomerID"])
    df["Revenue"] = df["Quantity"] * df["UnitPrice"]
    product = df.groupby("StockCode", as_index=False).agg(
        total_revenue=("Revenue", "sum"), total_quantity=("Quantity", "sum"),
        transaction_count=("InvoiceNo", "nunique"), mean_price=("UnitPrice", "mean"),
        customer_count=("CustomerID", "nunique"))
    product = product[(product.transaction_count >= 3) & (product.customer_count >= 1)].copy()
    threshold = product.total_revenue.quantile(0.75)
    product["success"] = (product.total_revenue >= threshold).astype(int)
    return product, {"initial_rows": initial_rows, "clean_rows": len(df), "products": len(product),
                     "duplicates_or_invalid_removed": initial_rows - len(df), "success_threshold_revenue": round(float(threshold), 2)}


def run_pandas():
    product, summary = prepare_features()
    features = ["total_quantity", "transaction_count", "mean_price", "customer_count"]
    # StockCode mengandung gabungan angka dan kode khusus; ubah ke string agar pengurutan stabil.
    ordered = product.assign(_sort_code=product.StockCode.astype(str)).sort_values("_sort_code").drop(columns="_sort_code").reset_index(drop=True)
    split = int(len(ordered) * 0.8)
    train, test = ordered.iloc[:split].copy(), ordered.iloc[split:].copy()
    means = train[features].mean(); stds = train[features].std().replace(0, 1)
    x_train = ((train[features] - means) / stds).values.tolist()
    x_test = ((test[features] - means) / stds).values.tolist()
    w = fit_logistic(x_train, train.success.tolist())
    metrics = score(test.success.tolist(), predict(w, x_test))
    summary.update({"engine": "pandas_local_equivalent", "train_products": len(train), "test_products": len(test),
                    "metrics": metrics, "features": features})
    RESULTS.mkdir(exist_ok=True)
    product.to_csv(RESULTS / "product_features.csv", index=False)
    (RESULTS / "metrics.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


def run_spark():
    # Proses fitur sengaja dipakai ulang agar aturan pembersihan dan agregasi konsisten.
    # SparkContext dipakai untuk mendistribusikan pembacaan objek fitur dan menguji RDD map/filter.
    from pyspark.sql import SparkSession
    product, summary = prepare_features()
    spark = SparkSession.builder.master("local[*]").appName("DMRDF-Partial-Replication").getOrCreate()
    rdd = spark.sparkContext.parallelize(product.to_dict("records"), 4)
    count = rdd.filter(lambda r: r["transaction_count"] >= 3).map(lambda r: r["StockCode"]).count()
    spark.stop()
    run_pandas()
    print(f"Spark RDD berhasil memproses {count} produk.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", choices=["auto", "pandas", "spark"], default="auto")
    args = parser.parse_args()
    download_if_needed()
    if args.engine == "spark":
        run_spark()
    elif args.engine == "auto":
        try:
            import pyspark  # noqa: F401
            if os.environ.get("JAVA_HOME") or os.system("java -version >nul 2>&1") == 0:
                run_spark()
            else:
                run_pandas()
        except ImportError:
            run_pandas()
    else:
        run_pandas()
